import React, { useState, useEffect } from "react";
import "./SearchBar.css";

interface Song {
  id: string;
  title: string;
}

interface SearchBarProps {
  songList: Song[];
  onSongSelect: (songTitle: string) => void;
  onSubmitGuess: (guess: string) => void;
  input: string;
  setInput: (val: string) => void;
}

export default function SearchBar({ songList, onSongSelect, onSubmitGuess , input, setInput}: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Song[]>([]);

  useEffect(() => {
    if (query.trim().length === 0) {
      setSuggestions([]);
      return;
    }

    const lower = query.toLowerCase();
    const matches = songList.filter(song => song.title.toLowerCase().includes(lower));
    setSuggestions(matches.slice(0, 10)); // limit to top 10
  }, [query, songList]);

  const handleSubmit = () => {
    if (query.trim()) {
      onSubmitGuess(input);
      setSuggestions([]); // optionally reset suggestions
    }
  };

  return (
    <div className="search-bar">
      <input
        type="text"
        value={query}
        onChange={e => setInput(e.target.value)}
        placeholder="Search for a song"
        className="search-input"
      />
      {suggestions.length > 0 && (
        <ul className="suggestion-list">
          {suggestions.map((song) => (
            <li
              key={song.id}
              onClick={() => {
                setQuery(song.title);
                setSuggestions([]);
                onSongSelect(song.title);
              }}
            >
              {song.title}
            </li>
          ))}
        </ul>
      )}
      <button className="submit-button" onClick={handleSubmit}>
        SUBMIT!
      </button>
    </div>
  );
}