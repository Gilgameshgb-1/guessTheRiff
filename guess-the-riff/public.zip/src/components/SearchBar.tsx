import "./SearchBar.css";

interface SearchBarProps {
  value: string;
  onChange: (val: string) => void;
  onSubmit: () => void;
}

export default function SearchBar({ value, onChange, onSubmit }: SearchBarProps) {
  return (
    <div className="search-bar">
      <input
        type="text"
        className="search-input"
        placeholder="Search for a song"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
      <button className="submit-button" onClick={onSubmit}>
        SUBMIT!
      </button>
    </div>
  );
}
