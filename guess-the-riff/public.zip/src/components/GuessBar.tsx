import { Zap } from "lucide-react";
import "./GuessBar.css";
import Skull from "../assets/skull.svg?react";
import Thunder from "../assets/thunder.svg?react";

interface GuessBarProps {
  currentGuess: number;
  totalGuesses: number;
  maxGuesses: number;
}

export default function GuessBar({ currentGuess, totalGuesses, maxGuesses }: GuessBarProps) {
  const guesses = Array.from({ length: maxGuesses }, (_, i) => i + 1);

  return (
    <div className="guess-bar">
      <div className="guess-icons">
        {guesses.map((guess) => (
          <div
            key={guess}
            className={`guess-box ${
              guess <= currentGuess ? "used" : guess === currentGuess + 1 ? "current" : ""
            }`}
          >
            {guess <= totalGuesses ?  <Skull className="skull-icon" /> : guess}
          </div>
        ))}
        <button className="skip-button">
          SKIP <Thunder className="thunder-icon"/>
        </button>
      </div>
      <p className="guess-remaining">
        {maxGuesses - totalGuesses} guesses remaining!
      </p>
    </div>
  );
}
