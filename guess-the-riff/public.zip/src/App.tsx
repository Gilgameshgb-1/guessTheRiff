import Header from "./components/Header";
import AudioPlayer from "./components/AudioPlayer";
import GuessBar from "./components/GuessBar";
import SearchBar from "./components/SearchBar"
import RiffControls from "./components/RiffControls";
import Footer from "./components/Footer"
import "./App.css";

function App() {
  return (
    <div className="app">
      <Header />
      <main className="main-content">
        <AudioPlayer />
        <GuessBar currentGuess={2} totalGuesses={2} maxGuesses={5} />
        <SearchBar />
        <RiffControls />
        <Footer />
      </main>
    </div>
  );
}

export default App;
